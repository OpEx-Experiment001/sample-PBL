// HealQueue - Hospital Queue Management System
// State Management
const state = {
  currentUser: null,
  currentPage: 'login',
  users: [
    { id: 1, name: 'Admin User', email: 'admin@healqueue.com', password: 'admin123', role: 'admin', status: 'active' },
    { id: 2, name: 'Dr. Sarah Johnson', email: 'doctor@healqueue.com', password: 'doctor123', role: 'doctor', status: 'active' },
    { id: 3, name: 'John Receptionist', email: 'receptionist@healqueue.com', password: 'recep123', role: 'receptionist', status: 'active' },
    { id: 4, name: 'Mary Nurse', email: 'nurse@healqueue.com', password: 'nurse123', role: 'nurse', status: 'active' },
  ],
  queue: [
    {
      token: 'TOK001',
      patient_name: 'John D.',
      full_name: 'John Doe',
      age: 45,
      gender: 'male',
      contact: '555-0101',
      department: 'Cardiology',
      status: 'waiting',
      wait_time_minutes: 25,
      registration_time: '09:15 AM',
      appointment_type: 'new',
      chief_complaint: 'Chest pain',
      vitals: null,
      location: 'Waiting Area'
    },
    {
      token: 'TOK002',
      patient_name: 'Jane S.',
      full_name: 'Jane Smith',
      age: 32,
      gender: 'female',
      contact: '555-0102',
      department: 'Pediatrics',
      status: 'in_progress',
      wait_time_minutes: 10,
      registration_time: '09:30 AM',
      appointment_type: 'followup',
      chief_complaint: 'Child vaccination',
      vitals: { bp: '120/80', hr: 75, temp: 98.6, spo2: 98, weight: 65, height: 165 },
      location: 'Consultation Room'
    },
    {
      token: 'TOK003',
      patient_name: 'Robert B.',
      full_name: 'Robert Brown',
      age: 58,
      gender: 'male',
      contact: '555-0103',
      department: 'General Medicine',
      status: 'waiting',
      wait_time_minutes: 15,
      registration_time: '09:45 AM',
      appointment_type: 'new',
      chief_complaint: 'General checkup',
      vitals: null,
      location: 'Waiting Area'
    }
  ],
  doctors: [
    { id: 1, name: 'Dr. Sarah Johnson', specialty: 'Cardiology', available: true },
    { id: 2, name: 'Dr. Michael Chen', specialty: 'Pediatrics', available: true },
    { id: 3, name: 'Dr. Emily Rodriguez', specialty: 'Orthopedics', available: false },
    { id: 4, name: 'Dr. James Williams', specialty: 'General Medicine', available: true }
  ],
  announcements: [
    {
      id: 1,
      title: 'Emergency Department Delay',
      message: 'Due to high patient volume, emergency department wait times may be longer than usual.',
      priority: 'high',
      timestamp: '2025-11-18 09:00 AM'
    },
    {
      id: 2,
      title: 'Dr. Rodriguez Unavailable',
      message: 'Dr. Emily Rodriguez is currently unavailable. Orthopedics appointments will be rescheduled.',
      priority: 'medium',
      timestamp: '2025-11-18 08:30 AM'
    }
  ],
  teamMembers: [
    { name: 'Dr. Sarah Johnson', role: 'Chief of Cardiology', bio: '15+ years of experience in cardiovascular medicine' },
    { name: 'Michael Anderson', role: 'Head Receptionist', bio: 'Ensuring smooth patient check-ins since 2015' },
    { name: 'Emily Chen', role: 'Senior Nurse', bio: 'Specialized in patient care and vitals monitoring' },
    { name: 'Admin Team', role: 'System Administrators', bio: 'Managing hospital operations and technology' }
  ],
  auditLogs: [
    { timestamp: '2025-11-18 09:15 AM', user: 'receptionist@healqueue.com', action: 'register', details: 'Registered patient TOK001', ip: '192.168.1.101' },
    { timestamp: '2025-11-18 09:30 AM', user: 'receptionist@healqueue.com', action: 'register', details: 'Registered patient TOK002', ip: '192.168.1.101' },
    { timestamp: '2025-11-18 09:45 AM', user: 'receptionist@healqueue.com', action: 'register', details: 'Registered patient TOK003', ip: '192.168.1.101' }
  ],
  tokenCounter: 4,
  selectedPatientForVitals: null,
  selectedPatientForConsultation: null
};

// Utility Functions
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  state.currentPage = pageId;
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast ${type} active`;
  setTimeout(() => {
    toast.classList.remove('active');
  }, 3000);
}

function addAuditLog(action, details) {
  const log = {
    timestamp: new Date().toLocaleString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
    user: state.currentUser ? state.currentUser.email : 'system',
    action: action,
    details: details,
    ip: `192.168.1.${Math.floor(Math.random() * 255)}`
  };
  state.auditLogs.unshift(log);
}

function getInitials(name) {
  return name.split(' ').map(n => n[0]).join('').toUpperCase();
}

function generateToken() {
  const token = `TOK${String(state.tokenCounter).padStart(3, '0')}`;
  state.tokenCounter++;
  return token;
}

// Login Functionality
function initLogin() {
  const loginForm = document.getElementById('loginForm');
  const loginError = document.getElementById('loginError');
  const viewPublicQueueBtn = document.getElementById('viewPublicQueueBtn');

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const role = document.getElementById('loginRole').value;

    const user = state.users.find(u => 
      (u.email === email || u.name === email) && 
      u.password === password && 
      u.role === role
    );

    if (user) {
      state.currentUser = user;
      addAuditLog('login', `User ${user.email} logged in as ${role}`);
      loginError.textContent = '';
      loginForm.reset();
      
      // Redirect to appropriate dashboard
      switch(role) {
        case 'admin':
          showPage('adminDashboard');
          initAdminDashboard();
          break;
        case 'doctor':
          showPage('doctorDashboard');
          initDoctorDashboard();
          break;
        case 'receptionist':
          showPage('receptionistDashboard');
          initReceptionistDashboard();
          break;
        case 'nurse':
          showPage('nurseDashboard');
          initNurseDashboard();
          break;
      }
    } else {
      loginError.textContent = 'Invalid credentials or role mismatch. Please try again.';
    }
  });

  viewPublicQueueBtn.addEventListener('click', () => {
    showPage('publicDashboard');
    initPublicDashboard();
  });

  document.getElementById('backToLoginBtn').addEventListener('click', () => {
    showPage('loginPage');
  });
}

// Public Dashboard
function initPublicDashboard() {
  renderPublicQueue();
  renderAnnouncements();
  renderDoctorAvailability();
  updatePublicStats();

  // Auto-refresh every 10 seconds
  const refreshInterval = setInterval(() => {
    if (state.currentPage === 'publicDashboard') {
      simulateQueueUpdates();
      renderPublicQueue();
      updatePublicStats();
    } else {
      clearInterval(refreshInterval);
    }
  }, 10000);
}

function renderPublicQueue() {
  const tbody = document.getElementById('publicQueueBody');
  tbody.innerHTML = '';

  state.queue.forEach(patient => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td><strong>${patient.token}</strong></td>
      <td>${patient.patient_name}</td>
      <td>${patient.department}</td>
      <td><span class="status-badge status-${patient.status}">${getStatusDisplay(patient.status)}</span></td>
      <td>${patient.wait_time_minutes} min</td>
    `;
    tbody.appendChild(row);
  });
}

function renderAnnouncements() {
  const container = document.getElementById('announcementsList');
  container.innerHTML = '';

  state.announcements.forEach(announcement => {
    const div = document.createElement('div');
    div.className = `announcement-item priority-${announcement.priority}`;
    div.innerHTML = `
      <div class="announcement-title">${announcement.title}</div>
      <div class="announcement-message">${announcement.message}</div>
      <div class="announcement-time">${announcement.timestamp}</div>
    `;
    container.appendChild(div);
  });
}

function renderDoctorAvailability() {
  const container = document.getElementById('doctorsList');
  container.innerHTML = '';

  state.doctors.forEach(doctor => {
    const div = document.createElement('div');
    div.className = 'doctor-item';
    div.innerHTML = `
      <div class="doctor-info">
        <h4>${doctor.name}</h4>
        <div class="doctor-specialty">${doctor.specialty}</div>
      </div>
      <span class="doctor-status ${doctor.available ? 'available' : 'unavailable'}">
        ${doctor.available ? 'Available' : 'Unavailable'}
      </span>
    `;
    container.appendChild(div);
  });
}

function updatePublicStats() {
  const waiting = state.queue.filter(p => p.status === 'waiting').length;
  const avgWait = Math.round(state.queue.reduce((sum, p) => sum + p.wait_time_minutes, 0) / state.queue.length);
  const served = state.queue.filter(p => p.status === 'completed').length;

  document.getElementById('totalWaiting').textContent = waiting;
  document.getElementById('avgWaitTime').textContent = avgWait;
  document.getElementById('servedToday').textContent = served;
}

function simulateQueueUpdates() {
  // Randomly update wait times
  state.queue.forEach(patient => {
    if (patient.status === 'waiting') {
      patient.wait_time_minutes = Math.max(5, patient.wait_time_minutes + Math.floor(Math.random() * 3) - 1);
    }
  });
}

function getStatusDisplay(status) {
  const statusMap = {
    'waiting': 'Waiting',
    'in_progress': 'In Progress',
    'completed': 'Completed',
    'cancelled': 'Cancelled'
  };
  return statusMap[status] || status;
}

// Admin Dashboard
function initAdminDashboard() {
  document.getElementById('adminWelcome').textContent = `Welcome, ${state.currentUser.name}`;
  
  setupTabNavigation('adminDashboard');
  renderUsersTable();
  renderSystemAnalytics();
  renderAuditLogs();
  renderTeam('teamGrid');
  setupDatabaseManagement();

  document.getElementById('adminLogout').addEventListener('click', logout);
  document.getElementById('addUserBtn').addEventListener('click', () => openUserModal());
  document.getElementById('exportLogsBtn').addEventListener('click', exportAuditLogs);
}

function renderUsersTable() {
  const tbody = document.getElementById('usersTableBody');
  tbody.innerHTML = '';

  state.users.forEach(user => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${user.id}</td>
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td><span class="status-badge status-info">${user.role}</span></td>
      <td><span class="status-badge status-${user.status === 'active' ? 'completed' : 'cancelled'}">${user.status}</span></td>
      <td>
        <div class="action-buttons">
          <button class="btn btn-sm btn-info" onclick="editUser(${user.id})">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">Delete</button>
        </div>
      </td>
    `;
    tbody.appendChild(row);
  });

  // Search and filter
  document.getElementById('userSearch').addEventListener('input', filterUsers);
  document.getElementById('userRoleFilter').addEventListener('change', filterUsers);
}

function filterUsers() {
  const search = document.getElementById('userSearch').value.toLowerCase();
  const roleFilter = document.getElementById('userRoleFilter').value;
  
  const rows = document.querySelectorAll('#usersTableBody tr');
  rows.forEach((row, index) => {
    const user = state.users[index];
    const matchesSearch = user.name.toLowerCase().includes(search) || user.email.toLowerCase().includes(search);
    const matchesRole = !roleFilter || user.role === roleFilter;
    row.style.display = matchesSearch && matchesRole ? '' : 'none';
  });
}

function openUserModal(userId = null) {
  const modal = document.getElementById('userModal');
  const form = document.getElementById('userForm');
  const title = document.getElementById('userModalTitle');

  if (userId) {
    const user = state.users.find(u => u.id === userId);
    title.textContent = 'Edit User';
    document.getElementById('userName').value = user.name;
    document.getElementById('userEmail').value = user.email;
    document.getElementById('userRole').value = user.role;
    document.getElementById('userPassword').value = user.password;
    form.dataset.userId = userId;
  } else {
    title.textContent = 'Add New User';
    form.reset();
    delete form.dataset.userId;
  }

  modal.classList.add('active');

  const closeBtn = modal.querySelector('.close');
  closeBtn.onclick = () => modal.classList.remove('active');
  
  document.getElementById('cancelUserBtn').onclick = () => modal.classList.remove('active');

  form.onsubmit = (e) => {
    e.preventDefault();
    const userData = {
      name: document.getElementById('userName').value,
      email: document.getElementById('userEmail').value,
      role: document.getElementById('userRole').value,
      password: document.getElementById('userPassword').value,
      status: 'active'
    };

    if (form.dataset.userId) {
      const user = state.users.find(u => u.id === parseInt(form.dataset.userId));
      Object.assign(user, userData);
      addAuditLog('user_action', `Updated user ${userData.email}`);
      showToast('User updated successfully');
    } else {
      userData.id = state.users.length + 1;
      state.users.push(userData);
      addAuditLog('user_action', `Created new user ${userData.email}`);
      showToast('User added successfully');
    }

    modal.classList.remove('active');
    renderUsersTable();
  };
}

function editUser(userId) {
  openUserModal(userId);
}

function deleteUser(userId) {
  if (confirm('Are you sure you want to delete this user?')) {
    const userIndex = state.users.findIndex(u => u.id === userId);
    const user = state.users[userIndex];
    state.users.splice(userIndex, 1);
    addAuditLog('user_action', `Deleted user ${user.email}`);
    showToast('User deleted successfully');
    renderUsersTable();
  }
}

function renderSystemAnalytics() {
  const patientsToday = state.queue.length;
  const avgWait = Math.round(state.queue.reduce((sum, p) => sum + p.wait_time_minutes, 0) / state.queue.length);
  const staffOnline = state.users.filter(u => u.status === 'active').length;
  const efficiency = Math.round((state.queue.filter(p => p.status === 'completed').length / patientsToday) * 100) || 0;

  document.getElementById('kpiPatientsToday').textContent = patientsToday;
  document.getElementById('kpiAvgWait').textContent = `${avgWait} min`;
  document.getElementById('kpiStaffOnline').textContent = staffOnline;
  document.getElementById('kpiEfficiency').textContent = `${efficiency}%`;

  // Department Chart
  const deptData = {};
  state.queue.forEach(p => {
    deptData[p.department] = (deptData[p.department] || 0) + 1;
  });

  const deptChart = new Chart(document.getElementById('departmentChart'), {
    type: 'bar',
    data: {
      labels: Object.keys(deptData),
      datasets: [{
        label: 'Patients',
        data: Object.values(deptData),
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: true }
      }
    }
  });

  // Status Chart
  const statusData = {};
  state.queue.forEach(p => {
    statusData[p.status] = (statusData[p.status] || 0) + 1;
  });

  const statusChart = new Chart(document.getElementById('statusChart'), {
    type: 'pie',
    data: {
      labels: Object.keys(statusData).map(s => getStatusDisplay(s)),
      datasets: [{
        data: Object.values(statusData),
        backgroundColor: ['#FF9800', '#2196F3', '#4CAF50', '#F44336']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true
    }
  });

  // Queue Insights
  const deptBreakdown = document.getElementById('deptBreakdown');
  deptBreakdown.innerHTML = Object.entries(deptData)
    .map(([dept, count]) => `<p><strong>${dept}:</strong> ${count} patients</p>`)
    .join('');

  const peakHours = document.getElementById('peakHours');
  peakHours.innerHTML = '<p><strong>Peak Hours:</strong> 9:00 AM - 11:00 AM</p><p><strong>Average:</strong> 12 patients/hour</p>';

  // Trend Chart
  const trendChart = new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
      labels: ['8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM'],
      datasets: [{
        label: 'Queue Length',
        data: [2, 5, 8, 6, 4, 3],
        borderColor: '#2196F3',
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true
    }
  });
}

function renderAuditLogs() {
  const tbody = document.getElementById('auditLogsBody');
  tbody.innerHTML = '';

  state.auditLogs.forEach(log => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${log.timestamp}</td>
      <td>${log.user}</td>
      <td><span class="status-badge status-info">${log.action}</span></td>
      <td>${log.details}</td>
      <td>${log.ip}</td>
    `;
    tbody.appendChild(row);
  });

  // Filter functionality
  document.getElementById('logSearch').addEventListener('input', filterLogs);
  document.getElementById('logActionFilter').addEventListener('change', filterLogs);
}

function filterLogs() {
  const search = document.getElementById('logSearch').value.toLowerCase();
  const actionFilter = document.getElementById('logActionFilter').value;
  
  const rows = document.querySelectorAll('#auditLogsBody tr');
  rows.forEach((row, index) => {
    const log = state.auditLogs[index];
    const matchesSearch = log.user.toLowerCase().includes(search) || log.details.toLowerCase().includes(search);
    const matchesAction = !actionFilter || log.action === actionFilter;
    row.style.display = matchesSearch && matchesAction ? '' : 'none';
  });
}

function exportAuditLogs() {
  const csv = ['Timestamp,User,Action,Details,IP Address'];
  state.auditLogs.forEach(log => {
    csv.push(`${log.timestamp},${log.user},${log.action},${log.details},${log.ip}`);
  });
  
  showToast('Audit logs exported successfully');
  addAuditLog('user_action', 'Exported audit logs');
}

function setupDatabaseManagement() {
  document.getElementById('dbTotalRecords').textContent = state.queue.length + state.users.length;
  document.getElementById('dbSize').textContent = '2.4 MB';
  document.getElementById('dbLastBackup').textContent = 'Today, 8:00 AM';

  document.getElementById('backupDbBtn').addEventListener('click', () => {
    document.getElementById('dbMessage').innerHTML = '<p>Database backup completed successfully!</p>';
    document.getElementById('dbMessage').className = 'message-box success';
    document.getElementById('dbLastBackup').textContent = 'Just now';
    addAuditLog('user_action', 'Database backup initiated');
  });

  document.getElementById('restoreDbBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to restore from backup?')) {
      document.getElementById('dbMessage').innerHTML = '<p>Database restored from last backup.</p>';
      document.getElementById('dbMessage').className = 'message-box success';
      addAuditLog('user_action', 'Database restore initiated');
    }
  });

  document.getElementById('integrityCheckBtn').addEventListener('click', () => {
    document.getElementById('dbMessage').innerHTML = '<p>✓ All integrity checks passed. No errors found.</p>';
    document.getElementById('dbMessage').className = 'message-box success';
    addAuditLog('user_action', 'Database integrity check performed');
  });
}

// Doctor Dashboard
function initDoctorDashboard() {
  document.getElementById('doctorWelcome').textContent = `Welcome, ${state.currentUser.name}`;
  
  setupTabNavigation('doctorDashboard');
  renderAssignedPatients();
  renderConsultationPanel();
  renderSchedule();
  renderTeam('doctorTeamGrid');

  document.getElementById('doctorLogout').addEventListener('click', logout);
}

function renderAssignedPatients() {
  const container = document.getElementById('assignedPatientsGrid');
  const cardioPatients = state.queue.filter(p => p.department === 'Cardiology');

  if (cardioPatients.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📋</div><h3>No Assigned Patients</h3><p>You have no patients assigned at the moment.</p></div>';
    return;
  }

  container.innerHTML = '';
  cardioPatients.forEach(patient => {
    const card = document.createElement('div');
    card.className = 'patient-card';
    card.innerHTML = `
      <div class="patient-card-header">
        <div class="patient-token">${patient.token}</div>
        <span class="status-badge status-${patient.status}">${getStatusDisplay(patient.status)}</span>
      </div>
      <div class="patient-details">
        <p><strong>Name:</strong> ${patient.full_name}</p>
        <p><strong>Age:</strong> ${patient.age}</p>
        <p><strong>Complaint:</strong> ${patient.chief_complaint}</p>
        <p><strong>Wait Time:</strong> ${patient.wait_time_minutes} min</p>
      </div>
      <div class="patient-actions">
        <button class="btn btn-sm btn-primary" onclick="selectPatientForConsultation('${patient.token}')">View Details</button>
        ${patient.status === 'waiting' ? `<button class="btn btn-sm btn-success" onclick="startConsultation('${patient.token}')">Start</button>` : ''}
        ${patient.status === 'in_progress' ? `<button class="btn btn-sm btn-success" onclick="completeConsultation('${patient.token}')">Complete</button>` : ''}
      </div>
    `;
    container.appendChild(card);
  });

  // Filter functionality
  document.getElementById('patientStatusFilter').addEventListener('change', (e) => {
    const filter = e.target.value;
    document.querySelectorAll('.patient-card').forEach(card => {
      if (!filter) {
        card.style.display = '';
      } else {
        const status = card.querySelector('.status-badge').className.includes(filter);
        card.style.display = status ? '' : 'none';
      }
    });
  });
}

function selectPatientForConsultation(token) {
  state.selectedPatientForConsultation = state.queue.find(p => p.token === token);
  document.querySelector('[data-tab="currentConsultation"]').click();
  renderConsultationPanel();
}

function startConsultation(token) {
  const patient = state.queue.find(p => p.token === token);
  patient.status = 'in_progress';
  patient.location = 'Consultation Room';
  addAuditLog('update', `Started consultation for patient ${token}`);
  showToast('Consultation started');
  renderAssignedPatients();
}

function completeConsultation(token) {
  const patient = state.queue.find(p => p.token === token);
  patient.status = 'completed';
  patient.location = 'Discharged';
  addAuditLog('update', `Completed consultation for patient ${token}`);
  showToast('Consultation completed');
  renderAssignedPatients();
  state.selectedPatientForConsultation = null;
  renderConsultationPanel();
}

function renderConsultationPanel() {
  const panel = document.getElementById('consultationPanel');
  
  if (!state.selectedPatientForConsultation) {
    panel.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🩺</div><h3>No Active Consultation</h3><p>Select a patient from the assigned patients list to begin.</p></div>';
    return;
  }

  const patient = state.selectedPatientForConsultation;
  panel.innerHTML = `
    <div class="patient-card" style="max-width: 700px;">
      <div class="patient-card-header">
        <div class="patient-token">${patient.token}</div>
        <span class="status-badge status-${patient.status}">${getStatusDisplay(patient.status)}</span>
      </div>
      <div class="patient-details">
        <p><strong>Name:</strong> ${patient.full_name}</p>
        <p><strong>Age:</strong> ${patient.age} | <strong>Gender:</strong> ${patient.gender}</p>
        <p><strong>Contact:</strong> ${patient.contact}</p>
        <p><strong>Chief Complaint:</strong> ${patient.chief_complaint}</p>
        <p><strong>Registration Time:</strong> ${patient.registration_time}</p>
      </div>
      ${patient.vitals ? `
        <div class="vitals-display" style="margin-top: 15px; padding: 15px; background: #f9f9f9; border-radius: 8px;">
          <h4 style="margin-bottom: 10px;">Vitals</h4>
          <p><strong>BP:</strong> ${patient.vitals.bp} | <strong>HR:</strong> ${patient.vitals.hr} bpm | <strong>Temp:</strong> ${patient.vitals.temp}°F</p>
          <p><strong>SpO2:</strong> ${patient.vitals.spo2}% | <strong>Weight:</strong> ${patient.vitals.weight} kg | <strong>Height:</strong> ${patient.vitals.height} cm</p>
        </div>
      ` : '<p style="color: #666; margin-top: 15px;">No vitals recorded yet.</p>'}
      <div class="form-group" style="margin-top: 20px;">
        <label>Consultation Notes</label>
        <textarea class="form-control" rows="4" placeholder="Enter consultation notes..."></textarea>
      </div>
      <div class="patient-actions" style="margin-top: 20px;">
        ${patient.status === 'waiting' ? `<button class="btn btn-primary" onclick="startConsultation('${patient.token}')">Start Consultation</button>` : ''}
        ${patient.status === 'in_progress' ? `<button class="btn btn-success" onclick="completeConsultation('${patient.token}')">Complete Consultation</button>` : ''}
      </div>
    </div>
  `;
}

function renderSchedule() {
  const container = document.getElementById('scheduleContent');
  const cardioPatients = state.queue.filter(p => p.department === 'Cardiology');
  
  container.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card-large">
        <h3>Today's Appointments</h3>
        <p class="stat-number">${cardioPatients.length}</p>
      </div>
      <div class="stat-card-large">
        <h3>Completed</h3>
        <p class="stat-number">${cardioPatients.filter(p => p.status === 'completed').length}</p>
      </div>
      <div class="stat-card-large">
        <h3>Pending</h3>
        <p class="stat-number">${cardioPatients.filter(p => p.status !== 'completed').length}</p>
      </div>
    </div>
    <div style="margin-top: 30px; background: white; padding: 20px; border-radius: 12px;">
      <h3>Schedule</h3>
      <p style="margin-top: 15px;">9:00 AM - 12:00 PM: Morning Consultations</p>
      <p>12:00 PM - 1:00 PM: Break</p>
      <p>1:00 PM - 5:00 PM: Afternoon Consultations</p>
    </div>
  `;
}

// Receptionist Dashboard
function initReceptionistDashboard() {
  document.getElementById('receptionistWelcome').textContent = `Welcome, ${state.currentUser.name}`;
  
  setupTabNavigation('receptionistDashboard');
  setupRegistrationForm();
  renderQueueBoard();
  renderReceptionistStats();
  renderTeam('receptionistTeamGrid');

  document.getElementById('receptionistLogout').addEventListener('click', logout);
}

function setupRegistrationForm() {
  const form = document.getElementById('registrationForm');
  
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const patientData = {
      token: generateToken(),
      patient_name: document.getElementById('patientName').value.split(' ')[0] + ' ' + document.getElementById('patientName').value.split(' ').pop()[0] + '.',
      full_name: document.getElementById('patientName').value,
      age: parseInt(document.getElementById('patientAge').value),
      gender: document.getElementById('patientGender').value,
      contact: document.getElementById('patientContact').value,
      department: document.getElementById('patientDepartment').value,
      status: 'waiting',
      wait_time_minutes: 0,
      registration_time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      appointment_type: document.getElementById('appointmentType').value,
      chief_complaint: document.getElementById('chiefComplaint').value,
      vitals: null,
      location: 'Waiting Area'
    };

    state.queue.push(patientData);
    addAuditLog('register', `Registered patient ${patientData.token} - ${patientData.full_name}`);
    
    // Show token display
    const tokenDisplay = document.getElementById('tokenDisplay');
    tokenDisplay.innerHTML = `
      <h3>✓ Registration Successful!</h3>
      <div class="token-number">${patientData.token}</div>
      <p>Patient: ${patientData.full_name}</p>
      <p>Department: ${patientData.department}</p>
      <p>Please proceed to the waiting area</p>
    `;
    tokenDisplay.classList.add('active');

    form.reset();
    showToast('Patient registered successfully');

    // Hide token display after 5 seconds
    setTimeout(() => {
      tokenDisplay.classList.remove('active');
    }, 5000);
  });
}

function renderQueueBoard() {
  const container = document.getElementById('queueBoard');
  
  if (state.queue.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📋</div><h3>No Patients in Queue</h3><p>The queue is currently empty.</p></div>';
    return;
  }

  container.innerHTML = '';
  state.queue.forEach(patient => {
    const item = document.createElement('div');
    item.className = 'queue-board-item';
    item.innerHTML = `
      <div class="queue-info">
        <h4>${patient.token} - ${patient.full_name}</h4>
        <p>Department: ${patient.department} | Status: ${getStatusDisplay(patient.status)}</p>
        <p>Contact: ${patient.contact} | Registered: ${patient.registration_time}</p>
      </div>
      <div class="queue-actions">
        ${patient.status === 'waiting' ? `<button class="btn btn-sm btn-primary" onclick="callPatient('${patient.token}')">Call Next</button>` : ''}
        <button class="btn btn-sm btn-danger" onclick="cancelAppointment('${patient.token}')">Cancel</button>
      </div>
    `;
    container.appendChild(item);
  });
}

function callPatient(token) {
  const patient = state.queue.find(p => p.token === token);
  patient.status = 'in_progress';
  addAuditLog('update', `Called patient ${token}`);
  showToast(`Patient ${token} called to consultation room`);
  renderQueueBoard();
}

function cancelAppointment(token) {
  if (confirm('Are you sure you want to cancel this appointment?')) {
    const patient = state.queue.find(p => p.token === token);
    patient.status = 'cancelled';
    addAuditLog('update', `Cancelled appointment for patient ${token}`);
    showToast('Appointment cancelled');
    renderQueueBoard();
  }
}

function renderReceptionistStats() {
  const total = state.queue.length;
  const newPatients = state.queue.filter(p => p.appointment_type === 'new').length;
  const followups = state.queue.filter(p => p.appointment_type === 'followup').length;

  document.getElementById('totalRegistrations').textContent = total;
  document.getElementById('totalWalkins').textContent = newPatients;
  document.getElementById('totalAppointments').textContent = followups;

  // Department distribution chart
  const deptData = {};
  state.queue.forEach(p => {
    deptData[p.department] = (deptData[p.department] || 0) + 1;
  });

  const chart = new Chart(document.getElementById('deptDistributionChart'), {
    type: 'doughnut',
    data: {
      labels: Object.keys(deptData),
      datasets: [{
        data: Object.values(deptData),
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true
    }
  });
}

// Nurse Dashboard
function initNurseDashboard() {
  document.getElementById('nurseWelcome').textContent = `Welcome, ${state.currentUser.name}`;
  
  setupTabNavigation('nurseDashboard');
  renderPreCheckQueue();
  renderVitalsPanel();
  renderMovementPanel();
  renderProgressionPanel();
  renderTeam('nurseTeamGrid');

  document.getElementById('nurseLogout').addEventListener('click', logout);
}

function renderPreCheckQueue() {
  const container = document.getElementById('preCheckList');
  const waitingPatients = state.queue.filter(p => p.status === 'waiting' && !p.vitals);

  if (waitingPatients.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">✅</div><h3>All Patients Checked</h3><p>No patients waiting for pre-check.</p></div>';
    return;
  }

  container.innerHTML = '';
  waitingPatients.forEach(patient => {
    const card = document.createElement('div');
    card.className = 'patient-card';
    card.innerHTML = `
      <div class="patient-card-header">
        <div class="patient-token">${patient.token}</div>
        <span class="status-badge status-waiting">Pending</span>
      </div>
      <div class="patient-details">
        <p><strong>Name:</strong> ${patient.full_name}</p>
        <p><strong>Age:</strong> ${patient.age}</p>
        <p><strong>Department:</strong> ${patient.department}</p>
      </div>
      <div class="patient-actions">
        <button class="btn btn-sm btn-primary" onclick="selectPatientForVitals('${patient.token}')">Enter Vitals</button>
      </div>
    `;
    container.appendChild(card);
  });
}

function selectPatientForVitals(token) {
  state.selectedPatientForVitals = state.queue.find(p => p.token === token);
  document.querySelector('[data-tab="vitalsEntry"]').click();
  renderVitalsPanel();
}

function renderVitalsPanel() {
  const panel = document.getElementById('vitalsPanel');
  
  if (!state.selectedPatientForVitals) {
    panel.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🩺</div><h3>No Patient Selected</h3><p>Select a patient from the pre-check queue to enter vitals.</p></div>';
    return;
  }

  const patient = state.selectedPatientForVitals;
  panel.innerHTML = `
    <form id="vitalsForm" class="vitals-form">
      <div class="vitals-header">
        <h3>${patient.token} - ${patient.full_name}</h3>
        <p>Age: ${patient.age} | Department: ${patient.department}</p>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Blood Pressure (systolic/diastolic)</label>
          <input type="text" id="vitalBP" class="form-control" placeholder="120/80" required>
        </div>
        <div class="form-group">
          <label>Heart Rate (bpm)</label>
          <input type="number" id="vitalHR" class="form-control" placeholder="75" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Temperature (°F)</label>
          <input type="number" step="0.1" id="vitalTemp" class="form-control" placeholder="98.6" required>
        </div>
        <div class="form-group">
          <label>Oxygen Saturation (%)</label>
          <input type="number" id="vitalSpO2" class="form-control" placeholder="98" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Weight (kg)</label>
          <input type="number" id="vitalWeight" class="form-control" placeholder="70" required>
        </div>
        <div class="form-group">
          <label>Height (cm)</label>
          <input type="number" id="vitalHeight" class="form-control" placeholder="170" required>
        </div>
      </div>
      <div class="form-group">
        <label>Nurse Notes</label>
        <textarea id="nurseNotes" class="form-control" rows="3" placeholder="Additional observations..."></textarea>
      </div>
      <div class="form-group">
        <label>
          <input type="checkbox" id="priorityFlag"> Mark as Priority
        </label>
      </div>
      <button type="submit" class="btn btn-primary btn-large">Save &amp; Send to Doctor</button>
    </form>
  `;

  document.getElementById('vitalsForm').addEventListener('submit', (e) => {
    e.preventDefault();
    saveVitals();
  });
}

function saveVitals() {
  const patient = state.selectedPatientForVitals;
  
  patient.vitals = {
    bp: document.getElementById('vitalBP').value,
    hr: parseInt(document.getElementById('vitalHR').value),
    temp: parseFloat(document.getElementById('vitalTemp').value),
    spo2: parseInt(document.getElementById('vitalSpO2').value),
    weight: parseInt(document.getElementById('vitalWeight').value),
    height: parseInt(document.getElementById('vitalHeight').value),
    notes: document.getElementById('nurseNotes').value
  };

  patient.location = 'Pre-check Complete';
  
  addAuditLog('update', `Vitals recorded for patient ${patient.token}`);
  showToast('Vitals saved successfully');
  
  state.selectedPatientForVitals = null;
  document.querySelector('[data-tab="preCheckQueue"]').click();
  renderPreCheckQueue();
}

function renderMovementPanel() {
  const panel = document.getElementById('movementPanel');
  
  panel.innerHTML = '<h3 style="margin-bottom: 20px;">Update Patient Location</h3>';
  
  state.queue.forEach(patient => {
    const item = document.createElement('div');
    item.className = 'movement-item';
    item.innerHTML = `
      <h4>${patient.token} - ${patient.full_name}</h4>
      <p><strong>Current Location:</strong> ${patient.location}</p>
      <div class="location-buttons">
        <button class="location-btn ${patient.location === 'Waiting Area' ? 'active' : ''}" onclick="updateLocation('${patient.token}', 'Waiting Area')">Waiting Area</button>
        <button class="location-btn ${patient.location === 'Pre-check Room' ? 'active' : ''}" onclick="updateLocation('${patient.token}', 'Pre-check Room')">Pre-check Room</button>
        <button class="location-btn ${patient.location === 'Consultation Room' ? 'active' : ''}" onclick="updateLocation('${patient.token}', 'Consultation Room')">Consultation</button>
        <button class="location-btn ${patient.location === 'Pharmacy' ? 'active' : ''}" onclick="updateLocation('${patient.token}', 'Pharmacy')">Pharmacy</button>
        <button class="location-btn ${patient.location === 'Lab' ? 'active' : ''}" onclick="updateLocation('${patient.token}', 'Lab')">Lab</button>
        <button class="location-btn ${patient.location === 'Discharged' ? 'active' : ''}" onclick="updateLocation('${patient.token}', 'Discharged')">Discharged</button>
      </div>
    `;
    panel.appendChild(item);
  });
}

function updateLocation(token, location) {
  const patient = state.queue.find(p => p.token === token);
  patient.location = location;
  addAuditLog('update', `Updated patient ${token} location to ${location}`);
  showToast(`Patient location updated to ${location}`);
  renderMovementPanel();
}

function renderProgressionPanel() {
  const panel = document.getElementById('progressionPanel');
  const priorityPatients = state.queue.filter(p => p.status === 'waiting');

  if (priorityPatients.length === 0) {
    panel.innerHTML = '<div class="empty-state"><div class="empty-state-icon">✅</div><h3>No Patients in Queue</h3><p>All patients have been processed.</p></div>';
    return;
  }

  panel.innerHTML = '<h3 style="margin-bottom: 20px;">Queue Progression</h3>';
  
  priorityPatients.forEach(patient => {
    const card = document.createElement('div');
    card.className = 'patient-card';
    card.innerHTML = `
      <div class="patient-card-header">
        <div class="patient-token">${patient.token}</div>
        <span class="status-badge status-${patient.status}">${getStatusDisplay(patient.status)}</span>
      </div>
      <div class="patient-details">
        <p><strong>Name:</strong> ${patient.full_name}</p>
        <p><strong>Department:</strong> ${patient.department}</p>
        <p><strong>Location:</strong> ${patient.location}</p>
        <p><strong>Wait Time:</strong> ${patient.wait_time_minutes} min</p>
      </div>
    `;
    panel.appendChild(card);
  });
}

// Team Rendering
function renderTeam(containerId) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';

  state.teamMembers.forEach((member, index) => {
    const card = document.createElement('div');
    card.className = 'team-card';
    card.innerHTML = `
      <div class="team-card-inner">
        <div class="team-card-front">
          <div class="team-photo">${getInitials(member.name)}</div>
          <div class="team-name">${member.name}</div>
          <div class="team-role">${member.role}</div>
        </div>
        <div class="team-card-back">
          <div class="team-bio">${member.bio}</div>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

// Tab Navigation
function setupTabNavigation(dashboardId) {
  const dashboard = document.getElementById(dashboardId);
  const navItems = dashboard.querySelectorAll('.nav-item');
  const tabContents = dashboard.querySelectorAll('.tab-content');

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const targetTab = item.dataset.tab;

      navItems.forEach(nav => nav.classList.remove('active'));
      item.classList.add('active');

      tabContents.forEach(content => content.classList.remove('active'));
      document.getElementById(targetTab).classList.add('active');
    });
  });
}

// Logout
function logout() {
  addAuditLog('login', `User ${state.currentUser.email} logged out`);
  state.currentUser = null;
  showPage('loginPage');
  showToast('Logged out successfully');
}

// Initialize Application
function init() {
  initLogin();
}

// Start the application
document.addEventListener('DOMContentLoaded', init);